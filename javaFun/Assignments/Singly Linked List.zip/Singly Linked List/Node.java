public class Node {
    public int val;
    public Node next;
    public Node() {
        // your code here
    }
    public Node(Integer value){
        this.val = value;
        this.next = null;
    }
}