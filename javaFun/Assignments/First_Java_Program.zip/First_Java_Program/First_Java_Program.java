import java.util.Scanner;

public class First_Java_Program {
    public static void main(String[] args) {
        Scanner input=new Scanner (System.in);
        String name = "Yassar Qureshi";
        int age = 100;
        String hometown = "Chicago";
        System.out.println("My name is " + name + " Coding Dojo");
        System.out.println("I am "+ age +" years old");
        System.out.println("My hometown is" + hometown + "Burbank,CA");

    }
}