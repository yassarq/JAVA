import java.util.Scanner;

import java.lang.Math;

public class Pythagorean_Theorem {
    public static void main(String[] args) {
        Pythagorean p = new Pythagorean();
        System.out.println(p.calculateHypotenuse(4, 5));
    }
}
