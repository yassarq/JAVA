public class FizzTest{
    public static void main(String[] args) {
        FizzBuzz b = new FizzBuzz();
        b.fizzBuzz(7);//putt another # instead of 7 to TEST!

    }
}
